from .risk_assesment import calc_cpa

__all__ = ['calc_cpa']